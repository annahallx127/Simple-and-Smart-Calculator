package calculator;

public abstract class AbstractCalculator<T extends AbstractCalculator<T>> implements Calculator {

  protected long currentOperand;
  protected char currentOperation;
  protected long result;
  protected StringBuilder display;
  protected int maxValue;
  protected boolean lastInputWasEqual;
  protected boolean lastInputWasOperator;

  protected AbstractCalculator() {
    this.currentOperand = 0;
    this.result = 0;
    this.display = new StringBuilder();
    this.maxValue = Integer.MAX_VALUE;
    this.currentOperation = '\0';
    this.lastInputWasEqual = false;
    this.lastInputWasOperator = false;
  }

  protected AbstractCalculator(long currentOperand, char currentOperation, long result,
                               StringBuilder display, int maxValue, boolean lastInputWasEqual,
                               boolean lastInputWasOperator) {
    this.currentOperand = currentOperand;
    this.currentOperation = currentOperation;
    this.result = result;
    this.display = new StringBuilder(display);
    this.maxValue = maxValue;
    this.lastInputWasEqual = lastInputWasEqual;
    this.lastInputWasOperator = lastInputWasOperator;
  }

  protected abstract T newInstance(long currentOperand, char currentOperation,
                                   long result, StringBuilder display, int maxValue,
                                   boolean lastInputWasEqual, boolean lastInputWasOperator);

  protected T clear() {
    return newInstance(0, '\0', 0, new StringBuilder(), maxValue, false, false);
  }

  @Override
  public Calculator input(char input) {
    if (input == 'C') {
      return clear();
    }
    if (display.length() == 0 && (input == '*' || input == '-')) {
      throw new IllegalArgumentException("Operation cannot start with this operator");
    }
    return newInstance(currentOperand, currentOperation, result, display, maxValue,
            true, false);
  }

  @Override
  public String getResult() {
    return display.toString();
  }

  protected T isValidDigit(char digit) {
    long newOperand = currentOperand;
    long newResult = result;
    StringBuilder newDisplay = new StringBuilder(display);

    String digitStr = Character.toString(digit);

    if (currentOperation != '\0') {
      String newOperandStr = currentOperand == 0 ? digitStr : (currentOperand) + digitStr;
      newOperand = Long.parseLong(newOperandStr);
      if (newOperand > maxValue) {
        throw new IllegalArgumentException("Operand exceeds maximum limit.");
      }
    } else {
      String newResultStr = result == 0 ? digitStr : (result) + digitStr;
      newResult = Long.parseLong(newResultStr);
      if (newResult > maxValue) {
        throw new IllegalArgumentException("Operation value exceeds maximum limit.");
      }
    }
    if (newDisplay.toString().equals("0")) {
      newDisplay.setLength(0);
    }
    newDisplay.append(digit);
    return newInstance(newOperand, currentOperation, newResult, newDisplay,
            maxValue, false, false);
  }

  protected T prepareOperation(char operation) {
    StringBuilder newDisplay = new StringBuilder(display);
    newDisplay.append(operation);

    return newInstance(0, operation, result, newDisplay, maxValue, false, true);
  }
}
